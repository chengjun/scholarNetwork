Coauthor-Network of Google Scholar
=======================

A project that exists as an aid to learn about your coauthor network based on Google Scholar files.
