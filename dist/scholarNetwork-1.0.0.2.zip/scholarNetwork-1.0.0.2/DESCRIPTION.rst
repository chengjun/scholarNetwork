Coauthor-Network of Google Scholar
=======================

This is the description file for the project.


An overview of the project



Basic usage examples



What's New?